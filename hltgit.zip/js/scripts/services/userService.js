app.service(
	"userService",
	['$rootScope','dataService','$cookies','$location',
		function($rootScope,dataService,$cookies,$location) {
			// Return public API.
			return({
				login: loginHandler,
				setNavigation: setNavigation,
				logout: logoutHandler,
				confirmLoggedinUser:confirmLoggedinUser,
			});
		
			function loginHandler(formDataJsonObj) {
				loginurl='api/login.php';
				data=formDataJsonObj;/*{userid:"",userpass:""}*/
				params={action: "login"};
				dataService.post(loginurl,data,params)
				.then( function(response){
					if (response.status!='passed') {
						console.log(response);
						alert(response.loginErrMsg+"\n"+response.errorDesc);
						$rootScope.loginErrMsg=response.loginErrMsg;
						localStorage.clear();
						setNavigation();
					}else{
						//set necessary cookies and redirect
						localStorage.setItem('isUserLoggedin',true);
						localStorage.setItem('userData',JSON.stringify(response.userData));
						localStorage.setItem('nav',JSON.stringify(response.nav));

						setNavigation(response.nav);
						$location.path('dashboard');
					}
				});
			}

			function setNavigation(navObj){
				savedNav=JSON.parse(localStorage.getItem('nav'));
				if (navObj==$rootScope.navObj && navObj==savedNav) {return;}
				if (navObj==null) {navObj=savedNav;}
				if (navObj==null) {
					$rootScope.navObj.modules={};
					$rootScope.navObj.extraMenu={};
					return $rootScope.navSet=true;
				}else{
					if (!navObj.modules){modules={};}else{modules=navObj.modules; }
					if (!navObj.more){more={};}else{more=navObj.more; }
				}
				if (modules){$rootScope.navObj.modules=modules; }
				if (more){$rootScope.navObj.extraMenu=more; }
				return $rootScope.navSet=true;
			}

			function logoutHandler(){
				logouturl='api/logout.php';
				data="";/*{userid:"",userpass:""}*/
				params={action: "logout"};
				dataService.post(logouturl,data,params)
				.then(
					function (response){
						localStorage.removeItem('isUserLoggedin');
						localStorage.removeItem('userData');
						localStorage.removeItem('nav');
						//setNavigation();
						//alert('userService:logoutHandler:post:success');
						//$location.path('home');
						window.location.href='http://educern.edu/spa/reload.php';
						return;
					},
					function (response){
						alert("An Error occured while logging you out! please check your internet connection and try again or simply reload this page");
						setNavigation();
						$location.path('home');
					}
				);
			}

			function confirmLoggedinUser() {
				//alert('confirmLoggedinUser');
				//check cookies for 
				if(
						(!localStorage.getItem('isUserLoggedin')) ||
						(!localStorage.getItem('userData')) ||
						(!localStorage.getItem('nav'))
					)
					{
						return false;
					}
				return true;
			}
		}
	]
);