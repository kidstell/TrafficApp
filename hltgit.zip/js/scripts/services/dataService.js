app.service(
	"dataService",
	['$http', '$q', '$httpParamSerializerJQLike','$location','$cookies',
		function($http, $q, $httpParamSerializerJQLike,$location,$cookies) {
			return({
				post: postHandler,
				get: getHandler,
			});

			function postHandler(requestUrl,requestData,requestParams,requestHeaders){
				if (requestHeaders==null) {requestHeaders={'Content-Type':'application/x-www-form-urlencoded'};}
				if (requestParams=='') {requestParams={};}
				var request = $http({
					method: "post",
					url: requestUrl,
					params: requestParams,
					data: $httpParamSerializerJQLike(requestData),/*"userid="+loginObj.userid+"&userpass="+loginObj.userpass,*/
					headers: requestHeaders
				});
				return( request.then( handleSuccess, handleError ) );
			}
		
			function getHandler(requestUrl,requestParams,requestHeaders){
				if (requestHeaders=='') {requestHeaders={'Content-Type':'application/x-www-form-urlencoded'};}
				if (requestParams=='') {requestParams={};}
				var request = $http({
					method: "get",
					url: requestUrl,
					params: requestParams,
					//data: $httpParamSerializerJQLike(requestData),/*"userid="+loginObj.userid+"&userpass="+loginObj.userpass,*/
					headers: requestHeaders
				});
				return( request.then( handleSuccess, handleError ) );
			}
		
			function handleError( response ) {
				// The API response from the server should be returned in a
				// nomralized format. However, if the request was not handled by the
				// server (or what not handles properly - ex. server error), then we
				// may have to normalize it on our end, as best we can.
				if (
					! angular.isObject( response.data ) ||
					! response.data.message
					) {
					return( $q.reject( "An unknown error occurred." ) );
				}
				// Otherwise, use expected error message.
				return( $q.reject( response.data.message ) );
			}

			function handleSuccess( response ) {
				if (response.data.system) {
					s=response.data.system;
					if (s=='die' || s=='abort') {
						//userService.logout;
						//manual logout because dataservice could not take userService as a dependency
						// $cookies.remove('isUserLoggedin');
						// $cookies.remove('userData');
						$location.path('logout');
						return;
					}
					if (s='location') {
						if (response.data.url){$location.path(response.data.url);}
						return;
					}
				}
				return( response.data );
			}
		}
	]
);