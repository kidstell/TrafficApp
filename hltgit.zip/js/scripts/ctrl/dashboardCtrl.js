app.controller(
	"dashboardCtrl",
	['$rootScope','$scope','$location','$cookies','dataService','userService',
		function($rootScope,$scope,$location,$cookies,dataService,userService) {
			$scope.cvrgopt={};
			$scope.spectrum={};
			$scope.spectrum.obj=JSON.parse(localStorage.getItem('spectrumObj'))||[];
			$scope.stateSelect=true;
			
			$scope.searchStr='';
			$scope.predicate='branch_name';
			$scope.reverse=true;
			$scope.displaySchool=false;
			$scope.displayState=false;
			$scope.displayLga=false;

			$scope.changeFilter=function(predicate){
				$scope.reverse=($scope.predicate===predicate)?!$scope.reverse:false;
				if (predicate==='school_name') {$scope.displaySchool=true; $scope.displayState=false; $scope.displayLga=false;}
				if (predicate==='state_name') {$scope.displaySchool=false; $scope.displayState=true; $scope.displayLga=false;}
				if (predicate==='lga_name') {$scope.displaySchool=false; $scope.displayState=true; $scope.displayLga=true;}
				$scope.predicate=predicate;
			}

			$scope.loadSpectrum=function(){

				if($scope.stateSelect) {
					if (!$scope.spectrum.state) {alert("select a state"); return;}
					spectrumid=$scope.spectrum.state;
				}else{
					if (!$scope.spectrum.coverage) {alert("select a coverage area"); return;}
					spectrumid=$scope.spectrum.coverage;
				}
				//userService.getSpectrum($scope.stateSelect,spectrumid,$scope.spectrum.scheme);
				data={useStates:$scope.stateSelect, id:spectrumid, academicScheme:$scope.spectrum.scheme};
				params={action: "get"};
				dataService.post('api/spectrum.php',data,params)
				.then(
					function (response){
						/*console.log(response);*/
						$scope.spectrum.obj=response;
						localStorage.setItem('spectrumObj',JSON.stringify(response));
					}, 
					function (response){alert("Operation Failed! try again"); }
				);
			}
		}
	]
);

