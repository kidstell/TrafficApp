app.controller(
	"logoutCtrl",
	['$scope','userService',
		function($scope,userService) {
			//alert('logoutCtrl');
			userService.logout();
		}
	]
);

