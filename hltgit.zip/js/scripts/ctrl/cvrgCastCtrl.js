app.controller(
	"cvrgCastCtrl",
	['$rootScope','$scope','$location','$cookies','dataService','userService',
		function($rootScope,$scope,$location,$cookies,dataService,userService) {
			$scope.butter={};//alert('done');
			$scope.butter.message="Loading...";

			$scope.chngeurl=function(){$scope.butter.includeUrl="api/cvrgCast.php?clientUrl="+$location.path();}
			$scope.chngeurl();

			
		}
	]
);

