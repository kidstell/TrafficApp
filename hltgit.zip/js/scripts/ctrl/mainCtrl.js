app.controller(
	"mainCtrl",
	['$rootScope','$scope','$location','dataService','$cookies','userService',
		function($rootScope,$scope,$location,dataService,$cookies,userService) {
			$rootScope.navObj={};
			$scope.loginErrMsg=false;
			
			userService.setNavigation();

			$scope.refresh=function(){
				//we cALL it refresh but it means logout
			}
		}
	]
);

