app.controller(
	"documentationCtrl",
	['$rootScope','$scope','$location','$cookies','dataService','userService',
		function($rootScope,$scope,$location,$cookies,dataService,userService) {
			//
		}
	]
);

