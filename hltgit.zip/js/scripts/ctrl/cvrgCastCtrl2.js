app.controller(
	"cvrgCastCtrl",
	['$rootScope','$scope','$location','$cookies','dataService','userService',
		function($rootScope,$scope,$location,$cookies,dataService,userService) {
			$scope.butter={};
			$scope.butter.message="Loading...";
			data={clientUrl:$location.path()};
			params={action: "get"};
			dataService.post('api/cvrgCast.php',data,params)
			.then(
				function (response){
					$scope.butter.bin=response;
					m=$(response.markup);
					console.log(response.markup);
					//alert(m.html());
					angular.element('.cvrg-container').html(response.markup);
					//base=$('.cvrg-container').html(response.markup);
				}, 
				function (response){alert("Operation Failed! try again");}
			);
		}
	]
);
