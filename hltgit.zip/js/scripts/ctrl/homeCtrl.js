app.controller(
	"homeCtrl",
	['$rootScope','$scope','$location','userService',
		function($rootScope,$scope,$location,userService) {
			$scope.login={};
			$scope.verifyUserData=function(){
				$scope.waiting=true;
				userService.login($scope.login);
				$scope.waiting=false;
			}

			$scope.loginStop=function() {
				$scope.waiting=false;
			};
		}
	]
);

