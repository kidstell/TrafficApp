app.config([
	'$routeProvider', 
	function($routeProvider) {
	$routeProvider
		.when('/', {
			resolve: {
				"check": function(userService,$location){
					if (userService.confirmLoggedinUser()) {
						$location.path('dashboard');
					}
				}
			},
			templateUrl: 'views/home.php',
			/*controller: 'homeCtrl'*/
		})
		.when('/dashboard', {
			resolve: {
				"check": function(userService,$location){
					if (!userService.confirmLoggedinUser()) {
						$location.path('home');
					}
				}
			},
			templateUrl: 'views/dashboard.php',
			/*controller: 'dashboardCtrl'*/
		})
		.when('/cvrgCast/:cvrgName*', {
			resolve: {
				"check": function(userService,$location){
					if (!userService.confirmLoggedinUser()) {
						$location.path('home');
					}
				}
			},
			templateUrl: 'views/cvrgCast.php',
			/*controller: 'cvrgCastCtrl'*/
		})
		.when('/documentation', {
			resolve: {
				"check": function(userService,$location){
					if (!userService.confirmLoggedinUser()) {
						$location.path('home');
					}
				}
			},
			templateUrl: 'views/documentation.php',
			/*controller: 'documentationCtrl'*/
		})
		.when('/logout', {
			resolve: {
				"check": function(userService,$location){
					if (!userService.confirmLoggedinUser()) {
						$location.path('home');
					}
				}
			},
			templateUrl: 'views/logout.php',
			/*controller: 'logoutCtrl'*/
		})
		.otherwise({
			redirectTo: '/'
		});
}]);